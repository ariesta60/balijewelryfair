<!DOCTYPE html>

<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- SEO -->
        <meta name="description" content="<?php echo esc_attr( stripslashes(get_option('niteoCS_descr', 'Just another Coming Soon Page')) ); ?>">
        <title><?php echo esc_html( stripslashes(get_option('niteoCS_title', get_bloginfo('name').' is coming soon!')) ); ?></title>

        <?php
        $themeslug = 'postery';
        // get theme related settings
        $niteoCS_active_color       = get_option('niteoCS_active_color['.$themeslug.']', '#E85C4F');
        $niteoCS_font_color         = get_option('niteoCS_font_color['.$themeslug.']', '#ffffff');
        $niteoCS_overlay_color      = get_option('niteoCS_overlay_color['.$themeslug.']', '#0a0a0a');
        $niteoCS_overlay_opacity    = get_option('niteoCS_overlay_opacity['.$themeslug.']', '0.4');
        $background_overlay         = $this->hex2rgba($niteoCS_overlay_color, $niteoCS_overlay_opacity);
        $content_font               = get_option('niteoCS_font_content['.$themeslug.']', 'Raleway');
        $heading_font               = get_option('niteoCS_font_headings['.$themeslug.']', 'Raleway');
        $headings_size              = get_option('niteoCS_font_headings_size['.$themeslug.']', '40');
        $heading_variant            = get_option('niteoCS_font_headings_variant['.$themeslug.']', '700');
        $headings_spacing           = get_option('niteoCS_font_headings_spacing['.$themeslug.']', '0');
        $content_size               = get_option('niteoCS_font_content_size['.$themeslug.']', '17');
        $content_variant            = get_option('niteoCS_font_content_variant['.$themeslug.']', 'regular');
        $content_lineheight         = get_option('niteoCS_font_content_lineheight['.$themeslug.']', '1.5');
        $content_spacing            = get_option('niteoCS_font_content_spacing['.$themeslug.']', '0');
        $content_variant            = ($content_variant =='regular') ? '400' : $content_variant;
        $heading_variant            = ($heading_variant =='regular') ? '400' : $heading_variant;
        $niteoCS_banner             = get_option('niteoCS_banner['.$themeslug.']', '1');

        if ( $heading_font == 'custom' ) {
            $heading_font = get_option('niteoCS_font_headings_custom['.$themeslug.']');
        }

        if ( $content_font == 'custom' ) {
            $content_font = get_option('niteoCS_font_content_custom['.$themeslug.']');
        }
        // get global settings
        $niteoCS_counter            = get_option('niteoCS_counter', '1');
        $niteoCS_counter_date       = get_option('niteoCS_counter_date', time()+86400);
        $countdown_action           = get_option('niteoCS_countdown_action', 'no-action');
        $body_title                 = get_option('niteoCS_body_title', 'SOMETHING IS HAPPENING!');
        $body                       = get_option('niteoCS_body');
        $copyright                  = get_option('niteoCS_copyright', 'Copyright 2017 NiteoThemes. All rights reserved.');
        $favicon_id                 = get_option('niteoCS_favicon_id');
        
        // override options if theme preview isset
        if ( isset( $theme_preview ) && $theme_preview == 'postery' ) {
            $body_title = 'OUR NEW WEBSITE';
            $body  = 'IS COMING
            SOON!';
        }

        // display favicon
        if ( $favicon_id && $favicon_id != '' ) {
            $favicon_url = wp_get_attachment_image_src($favicon_id, 'thumbnail');
            if ( isset($favicon_url[0]) ){
                echo '<link id="favicon" rel="shortcut icon" href="'.$favicon_url[0].'" type="image/x-icon"/>';
            } 
        } else {
           wp_site_icon();
        }

        if ( get_option( 'blog_public' ) == 0 ) {
            echo "<meta name='robots' content='noindex,nofollow' />";
        } ?>
        
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . $themeslug.'/style.css?v='.$this->version;?>" type="text/css" media="all">

        <style>
            body,input {font-family:'<?php echo esc_attr($content_font);?>', 'sans-serif';color:<?php echo esc_attr( $niteoCS_font_color ); ?>;}
            h1, h2, h3, h4, h5, h6 {font-family:'<?php echo esc_attr($heading_font);?>', 'sans-serif';}
            a {color:<?php echo esc_attr( $niteoCS_font_color ); ?>;}
            input[type="submit"] {background-color: <?php echo esc_attr($niteoCS_font_color);?>;}
            ::-webkit-input-placeholder {color: <?php echo esc_attr($niteoCS_font_color);?>;}
            ::-moz-placeholder {color: <?php echo esc_attr($niteoCS_font_color);?>;}
            :-ms-input-placeholder {color: <?php echo esc_attr($niteoCS_font_color);?>;}
            ::-moz-placeholder {color: <?php echo esc_attr($niteoCS_font_color);?>;}
            input[type="email"],input[type="text"]{color: <?php echo esc_attr($niteoCS_font_color);?>;}
            .counter-wrap,
            .social-list a,
            input[type="email"], input[type="text"] {background-color:<?php echo esc_attr( $this->hex2rgba($niteoCS_overlay_color, '0.2') );?>;}
            input[type="submit"] {background-color:<?php echo esc_attr($niteoCS_active_color);?>;}
            .social-list a {color: <?php echo esc_attr($niteoCS_font_color ); ?>;}
            .content{background-color:<?php echo esc_attr($background_overlay);?>;}
            
            <?php 
            //  if solid color banner, set social icons to same background color
            if ( $niteoCS_banner == 4) { ?>
                .social-list a {color: <?php echo esc_attr($banner_url ); ?>;background-color: <?php echo $this->hex2rgba($niteoCS_font_color, '0.2'); ?>;}
                .social-list a:hover {background-color: <?php echo esc_attr($niteoCS_font_color ); ?>;}
                <?php
            } ?>

            body {font-size:<?php echo esc_attr($content_size);?>px;letter-spacing: <?php echo esc_attr($content_spacing);?>px;font-weight:<?php echo esc_attr($content_variant);?>;}
            h1:not(.text-logo),h2, h3,h4,h5,h6,.text-logo-wrapper {font-size:<?php echo esc_attr($headings_size / $content_size);?>em;letter-spacing: <?php echo esc_attr($headings_spacing);?>px; font-weight:<?php echo esc_attr($heading_variant);?>;}
            
        </style>

        <?php 
        // custom CSS
        if ( get_option('niteoCS_custom_css', '') !== '' ) { ?>
            <!-- custom CSS -->
            <style>
            <?php 

            echo stripslashes(wp_filter_nohtml_kses(get_option('niteoCS_custom_css'))); ?> 
            </style> 
            <?php
        } 

        // GOOGLE ANALYTICS
        if ( get_option('niteoCS_analytics', '') !== '' ) { ?>
            <!-- Google analytics code -->
            <script>
              (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
              (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
              m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
              })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

              ga('create', '<?php echo esc_attr(get_option('niteoCS_analytics'));?>', 'auto');
              ga('send', 'pageview');

            </script>
            <?php 
        } 

        // echo pattern copyright
        if ( $niteoCS_banner == 3 ) {
             echo '<!-- Background pattern from Subtle Patterns --!>';
        } ?>

    </head>
    
    <!-- start body tag -->
    <body id="body">

        <div id="background-wrapper">
            <?php 
            if ( method_exists ( $html, 'cmp_background' ) ) {
                echo $html->cmp_background( $niteoCS_banner, $themeslug );

            } ?>
        </div>

            <div class="inner-content">
                <div class="content">
                    <?php 
                    // display logo
                    if ( method_exists ( $html, 'cmp_logo' ) ) {
                        echo $html->cmp_logo( $themeslug );
                    } 

                    // display title if not empty
                    if ( $body_title != '' ) { ?>
                        <h2 class="title slab">
                            <span class="slabtext heading"><?php echo esc_html( $body_title );?></span>
                        </h2>
                        <?php 
                    }
                    // display body content if not empty
                    if ( $body != '' ) { 

                        $body = explode(PHP_EOL, $body ); ?>
                        <p class="slab">
                            <?php
                            foreach ( $body as $body_part ) {
                                echo '<span class="slabtext">'.$body_part.'</span>';
                            } ?>
                        </p>
                        <?php 
                    } 

                    // display countdown timer if set
                    if ( $niteoCS_counter == '1') {
                        if ( get_option('niteoCS_translation') ) {
                            $translation    = json_decode( get_option('niteoCS_translation'), true );
                            $seconds        = $translation[0]['translation'];
                            $minutes        = $translation[1]['translation'];
                            $hours          = $translation[2]['translation'];
                            $days           = $translation[3]['translation'];
                        } else {
                            $seconds        = 'seconds';
                            $minutes        = 'minutes';
                            $hours          = 'hours';
                            $days           = 'days';
                        } ?>

                        <div id="counter" data-date="<?php echo esc_attr($niteoCS_counter_date);?>">
                            <div class="counter-wrap">
                                <div class="inner-counter">
                                    <span id="counter-day">00</span>
                                    <p><?php echo esc_html($days);?></p>
                                </div>
                            </div>

                            <div class="counter-wrap">
                                <div class="inner-counter">
                                <span id="counter-hour">00</span>
                                <p><?php echo esc_html($hours);?></p>
                                </div>
                            </div>

                            <div class="counter-wrap">
                                <div class="inner-counter">
                                <span id="counter-minute">00</span>
                                <p><?php echo esc_html($minutes);?></p>
                                </div>
                            </div>

                            <div class="counter-wrap">
                                <div class="inner-counter">
                                <span id="counter-second">00</span>
                                <p><?php echo esc_html($seconds);?></p>
                                </div>
                            </div>
                        </div>
                        <?php
                    }

                    // display subscribe form
                    if ( method_exists ( $html, 'cmp_subscribe_form' ) ) {
                        echo $html->cmp_subscribe_form( );
                    } ?>

                    <div class="subsribe-response"><?php echo isset( $subscribe_response ) ? $subscribe_response : '';?></div>

                    <?php

                    // display social icons
                    if ( method_exists ( $html, 'cmp_social_icons' ) ) {
                        echo $html->cmp_social_icons();
                    } ?>

                 </div>
                
            </div> <!-- .inner-content -->
                
        </div> <!-- #background-wrapper -->

        <?php
        // render javascripts
        if ( method_exists ( $html, 'cmp_javascripts' ) ) {
            $html->cmp_javascripts( $niteoCS_banner, $themeslug );
        } 

        // render script for redirect
        if ( method_exists ( $html, 'niteo_redirect' ) ) {
            $html->niteo_redirect();
        } 

        // if counter is enabled attach counter script
        if ( $niteoCS_counter == '1') { ?>
            <script>
                // Set the date we're counting down to
                var counter = document.getElementById('counter');
                var unixtime = counter.getAttribute('data-date');
                var date = new Date(unixtime*1000);
                var countDownDate = new Date(date).getTime();

                // Update the count down every 1 second
                var x = setInterval(function() {

                    // Get todays date and time
                    var now = new Date().getTime();
                    
                    // Find the distance between now an the count down date
                    var distance = countDownDate - now;
                    
                    // Time calculations for days, hours, minutes and seconds
                    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    if (days < 10) {
                        days = '0' + days;
                    }
                    if (hours < 10) {
                        hours = '0' + hours;
                    }
                    if (minutes < 10) {
                        minutes = '0' + minutes;
                    }
                    if (seconds < 10) {
                        seconds = '0' + seconds;
                    }
                    if (distance >= 0) {
                        document.getElementById('counter-day').innerHTML = days;
                        document.getElementById('counter-hour').innerHTML = hours;
                        document.getElementById('counter-minute').innerHTML = minutes;
                        document.getElementById('counter-second').innerHTML = seconds;   
                    }

                    <?php 
                    if ( $countdown_action != 'no-action' && $countdown_action != 'display-text') { ?>

                        // If the count down is over, write some text 
                        if (distance < 0) {
                            clearInterval(x);
                            window.location.reload();
                        }
                        <?php
                    } ?>

                }, 1000);
            </script>
            <?php 
        } ?>
            <!-- scripts needed for slabtext -->
            <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.slim.min.js'></script>
            <script type='text/javascript' src='<?php echo plugins_url('cmp-coming-soon-maintenance/themes/'.$themeslug.'/js/jquery.slabtext.min.js');?>'></script>
            <!-- slabtext script -->
        <script>
            // Function to slabtext the H1 headings
            function slabText() {
                $(".slab, .text-logo").slabText({
                    'maxFontSize': 450,
                    // Don't slabtext the headers if the viewport is under 380px
                    'onRender': function() {
                        setTimeout( function () {
                            var a =[];
                            $(".slabtextdone .slabtext").each( function(index){
                                a[index] = $(this);
                                setTimeout( function () {
                                   a[index].addClass('hover');
                               }, index * 800);
                            });
                        }, 500);
                        
                    }
                });
            };

            // Load fonts using google font loader
            var WebFontConfig = {
                google: { families: [ '<?php echo esc_attr(str_replace(' ', '+', $heading_font));?>', '<?php echo esc_attr(str_replace(' ', '+', $content_font));?>:400,400i,700' ] },
                // slabText the headers when the font has finished loading (or not)
                fontactive: slabText,
                fontinactive: slabText
            };
            (function() {
                var wf = document.createElement('script');
                wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
                wf.type = 'text/javascript';
                wf.async = 'true';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(wf, s);
            })();
        </script>

        </script>
        <?php 
        if ( !$this->isMobile() ) { ?>

            <!-- 3d rotating script -->
            <script>
                var moveForce = 30; // max popup movement in pixels
                var rotateForce = 20; // max popup rotation in deg

                $(document).mousemove(function(e) {
                    var docX = $(document).width();
                    var docY = $(document).height();
                    
                    var moveX = (e.pageX - docX/2) / (docX/2) * -moveForce;
                    var moveY = (e.pageY - docY/2) / (docY/2) * -moveForce;
                    
                    var rotateY = (e.pageX / docX * rotateForce*2) - rotateForce;
                    var rotateX = -((e.pageY / docY * rotateForce*2) - rotateForce);
                    
                    $('.content')
                        .css('left', moveX+'px')
                        .css('top', moveY+'px')
                        .css('transform', 'rotateX('+rotateX+'deg) rotateY('+rotateY+'deg)')
                        .css('-ms-transform', 'rotateX('+rotateX+'deg) rotateY('+rotateY+'deg)')
                        .css('-webkit-transform', 'rotateX('+rotateX+'deg) rotateY('+rotateY+'deg)');
                });

            </script>
            <?php 
        } ?>
    </body>
</html>
