<?php 
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

$theme_supports					= array(
	'logo' 			=> true,
	'slider' 		=> false,
	'counter' 		=> true,
	'subscribe' 	=> true,
	'social' 		=> true,
	'footer' 		=> false,
);

$niteoCS_banner 				= get_option('niteoCS_banner['.$themeslug.']', '1');
$niteoCS_font_headings   		= get_option('niteoCS_font_headings['.$themeslug.']', 'Raleway');
$niteoCS_font_content   		= get_option('niteoCS_font_content['.$themeslug.']', 'Raleway');

// get options
$niteoCS_active_color		= get_option('niteoCS_active_color['.$themeslug.']', '#E85C4F');
$niteoCS_font_color			= get_option('niteoCS_font_color['.$themeslug.']', '#ffffff');
$niteoCS_overlay_color 		= get_option('niteoCS_overlay_color['.$themeslug.']', '#0a0a0a');
$niteoCS_overlay_opacity 	= get_option('niteoCS_overlay_opacity['.$themeslug.']', '0.4');


